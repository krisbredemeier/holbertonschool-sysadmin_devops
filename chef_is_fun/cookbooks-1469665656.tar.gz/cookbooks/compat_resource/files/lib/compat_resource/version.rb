module CompatResource
  VERSION = '12.10.7'
end
