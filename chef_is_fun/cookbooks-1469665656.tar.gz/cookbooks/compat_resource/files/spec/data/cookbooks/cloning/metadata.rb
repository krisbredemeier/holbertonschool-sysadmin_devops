name "cloning"
description "cookbook that DOES NOT depend on compat_resource"
version "1.0.0"
